import React from 'react'
import '../style/style.css'
import '../style/mobile.css'

class Register extends React.Component{
  render(){
    return(
      <div className="b-register">
        <h2>
          Lorem ipsum is a placeholder text commonly used to demonstrate 
          the visual form of a document or a typeface without relying on 
          
        </h2>
        <span>Register Now</span>
      </div>
    );
  }
}

export default Register;